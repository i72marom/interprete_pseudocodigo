var searchData=
[
  ['progname',['progname',['../interpreter_8cpp.html#a13f3991d45154aa44f37dc1a4703e97f',1,'progname():&#160;interpreter.cpp'],['../interpreter_8y.html#a13f3991d45154aa44f37dc1a4703e97f',1,'progname():&#160;interpreter.cpp'],['../error_8cpp.html#a13f3991d45154aa44f37dc1a4703e97f',1,'progname():&#160;interpreter.cpp']]]
];
